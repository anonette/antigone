﻿Antigone Phase 1 scaled run
run_id: 20260525T081321Z_8b488b4a
models: 6 (current_multilingual) x 3 languages x 3 replicates = 54 cells
Import: upload this zip in Antigone Lab -> Import run
